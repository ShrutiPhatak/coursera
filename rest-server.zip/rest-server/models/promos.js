var mongoose=require('mongoose');
var schema=mongoose.Schema;
require('mongoose-currency').loadType(mongoose);
var currency=mongoose.Types.Currency;

var promoSchema=new schema({
    name:{
        type:String,
        required:true,
        unique:true
    },
    image:{
        type:String,
        required:true,
    },
    label:{
         type:String,
         default:""
    },
    price:{
        type:currency,
        required:true,
    },
    description:{
        type:String,
        required:true,
    }
},{timestamps:true});

var promos=mongoose.model('promo',promoSchema);
module.exports=promos;