var express=require('express');
var bodyParser=require('body-parser');
var leaderrouter=express.Router();
leaderrouter.use(bodyParser.json());

leaderrouter.route('/')

.all(function(req,res,next){
   res.writeHead(200,{'Content-Type':'text/html'});
    next();
})

.get(function(req,res,next){
   res.end("Send all leaders to you"); 
})

.post(function(req,res,next){
    res.send("will add leader "+req.body.name+" with promos "+req.body.description);
})

.delete(function(req,res,next){
   res.end("Delete all leaders"); 
});

leaderrouter.route('/:leaderId')
.get(function(req,res,next){
   res.end("will send details of "+req.params.leaderId); 
})

.put(function(req,res,next){
   res.write("updating the leader with id "+req.params.leaderId);
    res.end("will update the leader "+req.body.name +" with details "+req.body.description);
})

.delete(function(req,res,next){
    res.end("Deleting leader with dishId "+req.params.leaderId);
});

module.exports=leaderrouter;
