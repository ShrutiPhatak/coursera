var express=require('express');
var bodyParser=require('body-parser');
var promorouter=express.Router();
promorouter.use(bodyParser.json());

promorouter.route('/')

.all(function(req,res,next){
   res.writeHead(200,{'Content-Type':'text/html'});
    next();
})

.get(function(req,res,next){
   res.end("Send all promos to you"); 
})

.post(function(req,res,next){
    res.send("will add promos "+req.body.name+" with promos "+req.body.description);
})

.delete(function(req,res,next){
   res.end("Delete all promos"); 
});

promorouter.route('/:promoId')
.get(function(req,res,next){
   res.end("will send details of "+req.params.promoId); 
})

.put(function(req,res,next){
   res.write("updating the promos with id "+req.params.promoId);
    res.end("will update the promos "+req.body.name +" with details "+req.body.description);
})

.delete(function(req,res,next){
    res.end("Deleting promos with dishId "+req.params.promoId);
});

module.exports=promorouter;
